package com.test.ticketbookapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.ticketbookapp.entity.Ticket;
import com.test.ticketbookapp.repository.TicketRepository;

@Service
public class TicketService {
 
	@Autowired
	private TicketRepository ticketRepository;
	
	public List<Ticket> getAllTickets(){
		return ticketRepository.findAll();
	}
	public Ticket bookTicket(Ticket ticket) {
		 ticket.setReserved(true);
        return ticketRepository.save(ticket);
		
	}
	public List<Ticket> getAvailableTickets(){
		return ticketRepository.findByReserved(false);
	}
}
