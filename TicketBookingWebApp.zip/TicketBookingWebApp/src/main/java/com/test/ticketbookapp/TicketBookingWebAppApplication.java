package com.test.ticketbookapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketBookingWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketBookingWebAppApplication.class, args);
	}

}
