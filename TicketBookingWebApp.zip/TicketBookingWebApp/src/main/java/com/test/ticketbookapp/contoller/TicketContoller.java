package com.test.ticketbookapp.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.ticketbookapp.entity.Ticket;
import com.test.ticketbookapp.service.TicketService;

@RestController
@RequestMapping("/api/tickets")
public class TicketContoller {
	
@Autowired
private TicketService ticketService; 

@GetMapping
public List<Ticket> getAllTicktes() {
	return  ticketService.getAllTickets();
}

@PostMapping
public Ticket bookTicket(@RequestBody Ticket ticket) {
	return ticketService.bookTicket(ticket);
	
}
@GetMapping("/avialable")
public List<Ticket> getAvailableTickets() {
	return  ticketService.getAvailableTickets();
}

}
