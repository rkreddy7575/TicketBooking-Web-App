
import React, { useState } from 'react';
import axios from 'axios';

function BookingForm() {
    const [seatNumber, setSeatNumber] = useState('');

    const handleSeatChange = (event) => {
        setSeatNumber(event.target.value);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        axios.post('/api/tickets', { seatNumber })
            .then(response => {
                console.log('Ticket booked:', response.data);
                setSeatNumber('');
            })
            .catch(error => console.error('Error booking ticket:', error));
    };

    return (
        <div>
            <h2>Book a Ticket</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Seat Number:
                    <input type="text" value={seatNumber} onChange={handleSeatChange} />
                </label>
                <button type="submit">Book</button>
            </form>
        </div>
    );
}

export default BookingForm;