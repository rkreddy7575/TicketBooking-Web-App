import React,{useState, useEffect} from 'react';
import axios from 'axios';


function TicketList(){
    const [tickets, setTickets]=useState([]);
    useEffect(()=>{
        axios.get('/api/tickets')
        .then(response=>setTickets(rsponse.data)).catch(error=>('Error fetching details',error));
    
    },[]);
    return(
        <div>
            <h2>All Tickets</h2>
            <ul>{tickets.map(ticket=>(
            <li key={tickets.id}>{tickets.setNumber}-{ticket.reserved ?'Reserved':'Available'}</li>
            ))}
            </ul>
        </div>
        );
}
export default TicketList;