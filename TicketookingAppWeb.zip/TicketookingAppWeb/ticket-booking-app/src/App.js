import './App.css';
import React from 'react';
import TicketList from './TicketList/TicketList';
import BookingForm from './TicketList/BookingForm';

function App() {
  return (
    <div className="App">
      <TicketList />
      <BookingForm />
    </div>
  );
}

export default App;

